
    
<?php $__env->startSection('content'); ?>
        <div class="flex-centerbetween mb-4">
            <h2 class="text-dark fw-bold mb-0">Menu</h2>
            <a href="<?php echo e(route('menu.create')); ?>" class="btn btn-primary">
                <i class="bx bx-plus"></i> Tambah Menu
            </a>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Gambar</th>
                                <th>Nama Menu</th>
                                <th>Kategori Menu</th>
                                <th>Harga</th>
                                <th>Stock</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td><img src="<?php echo e(asset('storage/' . $menu->image)); ?>" alt="" class="rounded object-fit-cover" width="40"></td>
                                <td><?php echo e($menu->name); ?></td>
                                <td><?php echo e($menu->category->name); ?></td>
                                <td>Rp<?php echo e(number_format($menu->price,  0, ',', '.')); ?></td>
                                <td><?php echo e(number_format($menu->stock, 0, ',', '.')); ?></td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2">
                                        <a href="<?php echo e(route('menu.edit', $menu->id)); ?>" class="btn btn-warning btn-sm py-1 px-3 rounded-1 text-white">
                                            <i class="bx bx-edit"></i> Edit
                                        </a>
                                           <form action="<?php echo e(route('menu.destroy', $menu->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm py-1 px-3 rounded-1">
                                                    <i class="bx bx-trash"></i> hapus
                                                </button>
                                           </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADVAN\Documents\laravel\kasirdua\kasirdua\resources\views/pages/admin/menu/index.blade.php ENDPATH**/ ?>