
    
<?php $__env->startSection('content'); ?>
       <div class="flex-centerbetween mb-4">
            <h2 class="text-dark fw-bold mb-0">Tambah Kasir</h2>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <form action="<?php echo e(route('cashiers.update', $users->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="name">Nama</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name', $users->name)); ?>" autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="username">username</label>
                        <input type="text" name="username" class="form-control" id="email" value="<?php echo e(old('username', $users->username)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control" id="password">
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">
                            <i class="bx bx-save"></i> Simpan Baru
                        </button>
                        <a href="<?php echo e(url('kasir')); ?>" class="btn btn-danger">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADVAN\Documents\laravel\kasirdua\kasirdua\resources\views/pages/cashiers/edit.blade.php ENDPATH**/ ?>