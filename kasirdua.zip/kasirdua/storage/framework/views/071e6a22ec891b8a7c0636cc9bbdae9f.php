

<?php $__env->startSection('content'); ?>
    <section class="container-fluid px-1 px-lg-5">
        <div class="flex-centerbetween mb-4">
            <h2 class="text-dark fw-bold mb-0">Tambah Menu</h2>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('menu.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name">Nama Menu</label>
                        <input type="text" name="name" class="form-control" id="name" autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="category">Kategori</label>
                        <select name="category_id" id="category_id" class="form-select mb-2">
                            <option value="" selected disabled>Pilih Kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="">harga</label>
                        <div class="d-flex align-item-center gap-2">
                            Rp
                                <input type="text" name="priceDisplay" id="priceDisplay" class="w-100 form-control">
                                <input type="hidden" name="price" id="price">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="">stok</label>
                        <input type="text" name="stockDisplay" id="stockDisplay" class="w-100 form-control">
                        <input type="hidden" name="stock" id="stock">
                    </div>
                    <div class="mb-3">
                        <label for="imageInput">Gambar Produk</label>
                        <input type="file" name="image" id="imageInput" class="form-control"
                            placeholder="image here..." onchange="previewImage()">
                        <span class="text-danger d-block mt-1"><?php echo e($errors->first('imageInput')); ?></span>
                        <img class="mt-4" id="imagePreview" src="#" alt="Preview"
                            style="display: none; max-width: 100%; max-height: 200px">
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">
                            <i class="bx bx-save"></i> Simpan Baru
                        </button>
                        <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-light">
                            <i class="bx bx-arrow-back"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <script>
        function previewImage() {
            const input = document.getElementById('imageInput');
            const preview = document.getElementById('imagePreview');

            if (input.files && input.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }

                reader.readAsDataURL(input.files[0]);
            }
        };
        // 
        document.addEventListener('DOMContentLoaded', function(){
        const priceDisplayInput = document.querySelector('#priceDisplay');
        const priceInput = document.querySelector('#price');

        function formatPriceInput() {
            const value = this.value.replace(/[^0-9]/g, '');
            priceInput.value = value;
            this.value = value ? new Intl.NumberFormat('id-ID').format(value) : '';
        }

        priceDisplayInput.addEventListener('input', formatPriceInput);
       });

       document.addEventListener('DOMContentLoaded', function(){
        const stockDisplayInput = document.querySelector('#stockDisplay');
        const stockInput = document.querySelector('#stock');

        function formatStockInput() {
            const value = this.value.replace(/[^0-9]/g, '');
            stockInput.value = value;
            this.value = value ? new Intl.NumberFormat('id-ID').format(value) : '';
        }

        stockDisplayInput.addEventListener('input', formatStockInput);
       });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADVAN\Documents\laravel\kasirdua\kasirdua\resources\views/pages/admin/menu/create.blade.php ENDPATH**/ ?>