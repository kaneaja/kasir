<link rel="stylesheet" href="<?php echo e(url('assets/vendors/bootstrap/css/bootstrap.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(url('assets/vendors/boxicons/css/boxicons.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
  <?php /**PATH C:\Users\ADVAN\Documents\laravel\kasirdua\kasirdua\resources\views/components/style.blade.php ENDPATH**/ ?>