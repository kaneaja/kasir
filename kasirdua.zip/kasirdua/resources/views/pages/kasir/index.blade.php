@extends('layouts.kasir')
    
@section('content')
        <livewire:kasir />
@endsection