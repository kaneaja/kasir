<link rel="stylesheet" href="{{url('assets/vendors/bootstrap/css/bootstrap.min.css')}}">
     <link rel="stylesheet" href="{{url('assets/vendors/boxicons/css/boxicons.min.css')}}">
     <link rel="stylesheet" href="{{url('assets/css/style.css')}}">
  